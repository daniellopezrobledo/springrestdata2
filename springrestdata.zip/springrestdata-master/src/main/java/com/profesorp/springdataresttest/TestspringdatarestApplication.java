package com.profesorp.springdataresttest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestspringdatarestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestspringdatarestApplication.class, args);
	}

}
